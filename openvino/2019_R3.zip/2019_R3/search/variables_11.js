var searchData=
[
  ['scale',['scale',['../classInferenceEngine_1_1PowerLayer.html#a7125cd8b17e5839077f0334f8511f51a',1,'InferenceEngine::PowerLayer']]],
  ['seq_5faxis',['seq_axis',['../classInferenceEngine_1_1ReverseSequenceLayer.html#a541ae40fefc9fd04567d9c05c621a1f7',1,'InferenceEngine::ReverseSequenceLayer']]],
  ['shape',['shape',['../classInferenceEngine_1_1ReshapeLayer.html#af7d369daa0bd20586c4f6c0068e2e9f8',1,'InferenceEngine::ReshapeLayer']]],
  ['shrink_5faxis_5fmask',['shrink_axis_mask',['../classInferenceEngine_1_1StridedSliceLayer.html#adba80ed5397e8aa6302bda38eed90220',1,'InferenceEngine::StridedSliceLayer']]],
  ['sid',['sId',['../structInferenceEngine_1_1PrimitiveInfo.html#a36d98e70a08aeb4d9ec0cc4fdd6233ef',1,'InferenceEngine::PrimitiveInfo']]],
  ['sort',['sort',['../classInferenceEngine_1_1TopKLayer.html#ad7b432110784472b9f2e68dc8aa10356',1,'InferenceEngine::TopKLayer']]],
  ['sorted',['sorted',['../classInferenceEngine_1_1UniqueLayer.html#a968b7cd1c3145f7b4e700f07b99b152f',1,'InferenceEngine::UniqueLayer']]],
  ['start',['start',['../structInferenceEngine_1_1TensorIterator_1_1PortMap.html#a4b2c93d61957af4a7f690dbf4469fc4e',1,'InferenceEngine::TensorIterator::PortMap']]],
  ['stdscale',['stdScale',['../structInferenceEngine_1_1PreProcessChannel.html#a9a9ca23fe117f2527353d149c4371d5f',1,'InferenceEngine::PreProcessChannel']]],
  ['stride',['stride',['../structInferenceEngine_1_1TensorIterator_1_1PortMap.html#a7e9fd0dd49c6af7712a1fc56062b753b',1,'InferenceEngine::TensorIterator::PortMap']]],
  ['stype',['sType',['../structInferenceEngine_1_1PrimitiveInfo.html#a2d7b8843e1ff9957ce5f5de971dd3cac',1,'InferenceEngine::PrimitiveInfo']]],
  ['supportedlayers',['supportedLayers',['../structInferenceEngine_1_1QueryNetworkResult.html#a81e1efbc2b538ebb049bc62aedb18fa6',1,'InferenceEngine::QueryNetworkResult']]],
  ['supportedlayersmap',['supportedLayersMap',['../structInferenceEngine_1_1QueryNetworkResult.html#aff431e5d7451f364dee1c1c54ca78333',1,'InferenceEngine::QueryNetworkResult']]]
];
