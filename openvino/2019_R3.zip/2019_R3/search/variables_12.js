var searchData=
[
  ['tensordesc',['tensorDesc',['../classInferenceEngine_1_1Blob.html#a179aef7d9334c3a1366e45b18757a152',1,'InferenceEngine::Blob']]],
  ['tiles',['tiles',['../classInferenceEngine_1_1TileLayer.html#a73bfef9c45b9b5a60e27e2d3c1ee8430',1,'InferenceEngine::TileLayer']]],
  ['to',['to',['../structInferenceEngine_1_1TensorIterator_1_1PortMap.html#a6c4c0cb8316811c0c34d2b065a6f7666',1,'InferenceEngine::TensorIterator::PortMap']]],
  ['transpose_5fa',['transpose_a',['../classInferenceEngine_1_1GemmLayer.html#ac7f47597284f1bdfecb4b1ec6c72b873',1,'InferenceEngine::GemmLayer']]],
  ['transpose_5fb',['transpose_b',['../classInferenceEngine_1_1GemmLayer.html#a791f8d0f630a45afeabfed91357883a8',1,'InferenceEngine::GemmLayer']]],
  ['type',['type',['../structInferenceEngine_1_1LayerParams.html#a9540b56f6830cdf1a269c112284fb098',1,'InferenceEngine::LayerParams::type()'],['../classInferenceEngine_1_1CNNLayer.html#ac212155e7134b88e70eb244ffb03d079',1,'InferenceEngine::CNNLayer::type()']]]
];
