var searchData=
[
  ['fpga_20plugin',['FPGA Plugin',['../_docs_IE_DG_supported_plugins_FPGA.html',1,'']]],
  ['face_2ddetection_2dadas_2d0001',['face-detection-adas-0001',['../_models_intel_face_detection_adas_0001_description_face_detection_adas_0001.html',1,'']]],
  ['face_2ddetection_2dadas_2dbinary_2d0001',['face-detection-adas-binary-0001',['../_models_intel_face_detection_adas_binary_0001_description_face_detection_adas_binary_0001.html',1,'']]],
  ['face_2ddetection_2dretail_2d0004',['face-detection-retail-0004',['../_models_intel_face_detection_retail_0004_description_face_detection_retail_0004.html',1,'']]],
  ['face_2ddetection_2dretail_2d0005',['face-detection-retail-0005',['../_models_intel_face_detection_retail_0005_description_face_detection_retail_0005.html',1,'']]],
  ['face_2dreidentification_2dretail_2d0095',['face-reidentification-retail-0095',['../_models_intel_face_reidentification_retail_0095_description_face_reidentification_retail_0095.html',1,'']]],
  ['facial_2dlandmarks_2d35_2dadas_2d0002',['facial-landmarks-35-adas-0002',['../_models_intel_facial_landmarks_35_adas_0002_description_facial_landmarks_35_adas_0002.html',1,'']]]
];
