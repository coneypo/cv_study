var searchData=
[
  ['raw',['RAW',['../namespaceInferenceEngine.html#a5ee5ca7708cc67a9a0becc2593d0558aa1af35e096785969a23b3048b2b0fc06b',1,'InferenceEngine']]],
  ['result_5fready',['RESULT_READY',['../classInferenceEngine_1_1IInferRequest.html#a5f403eaa522c38611d152399b616a848aaf5018bbb6697150c76024689c52dfc9',1,'InferenceEngine::IInferRequest']]],
  ['rgb',['RGB',['../namespaceInferenceEngine.html#a5ee5ca7708cc67a9a0becc2593d0558aae2262afdcd9754598dbc87e4a4725246',1,'InferenceEngine']]],
  ['rgbx',['RGBX',['../namespaceInferenceEngine.html#a5ee5ca7708cc67a9a0becc2593d0558aa7ae5805f878c77d92c277585c41df041',1,'InferenceEngine']]],
  ['rnn',['RNN',['../classInferenceEngine_1_1RNNCellBase.html#aa0c9020aaea4ab61d36b9ef112207ca3a2085e85695ce4f41c62f5a198f4f397e',1,'InferenceEngine::RNNCellBase']]]
];
