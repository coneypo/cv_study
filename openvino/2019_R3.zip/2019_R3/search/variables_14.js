var searchData=
[
  ['validators',['validators',['../structInferenceEngine_1_1Builder_1_1ValidatorsHolder.html#a1e3fee23fc3ea61ef20ff3ff90533bd4',1,'InferenceEngine::Builder::ValidatorsHolder']]]
];
