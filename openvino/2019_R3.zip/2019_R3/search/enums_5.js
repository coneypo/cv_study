var searchData=
[
  ['normtype',['NormType',['../classInferenceEngine_1_1Builder_1_1NormLayer.html#a5e340f864691acef655f695f72894e7c',1,'InferenceEngine::Builder::NormLayer']]]
];
