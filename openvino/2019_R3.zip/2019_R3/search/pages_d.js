var searchData=
[
  ['neural_20style_20transfer_20python_2a_20sample',['Neural Style Transfer Python* Sample',['../_inference_engine_ie_bridges_python_sample_style_transfer_sample_README.html',1,'']]],
  ['neural_20style_20transfer_20c_2b_2b_20sample',['Neural Style Transfer C++ Sample',['../_inference_engine_samples_style_transfer_sample_README.html',1,'']]]
];
