var searchData=
[
  ['userobject',['userObject',['../classInferenceEngine_1_1Data.html#a05ccc8b4379ab65b85482bc3b2270513',1,'InferenceEngine::Data']]],
  ['uservalue',['userValue',['../classInferenceEngine_1_1CNNLayer.html#a62f7fc6af3a34b8b069025bfed12f37d',1,'InferenceEngine::CNNLayer']]]
];
