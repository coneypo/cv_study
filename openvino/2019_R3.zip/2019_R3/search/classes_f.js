var searchData=
[
  ['scaleshiftlayer',['ScaleShiftLayer',['../classInferenceEngine_1_1Builder_1_1ScaleShiftLayer.html',1,'InferenceEngine::Builder']]],
  ['scaleshiftlayer',['ScaleShiftLayer',['../classInferenceEngine_1_1ScaleShiftLayer.html',1,'InferenceEngine']]],
  ['scatterlayer',['ScatterLayer',['../classInferenceEngine_1_1ScatterLayer.html',1,'InferenceEngine']]],
  ['selectlayer',['SelectLayer',['../classInferenceEngine_1_1SelectLayer.html',1,'InferenceEngine']]],
  ['shapeinferextension',['ShapeInferExtension',['../classInferenceEngine_1_1ShapeInferExtension.html',1,'InferenceEngine']]],
  ['shufflechannelslayer',['ShuffleChannelsLayer',['../classInferenceEngine_1_1ShuffleChannelsLayer.html',1,'InferenceEngine']]],
  ['sigmoidlayer',['SigmoidLayer',['../classInferenceEngine_1_1Builder_1_1SigmoidLayer.html',1,'InferenceEngine::Builder']]],
  ['simplernmslayer',['SimplerNMSLayer',['../classInferenceEngine_1_1Builder_1_1SimplerNMSLayer.html',1,'InferenceEngine::Builder']]],
  ['softmaxlayer',['SoftMaxLayer',['../classInferenceEngine_1_1SoftMaxLayer.html',1,'InferenceEngine']]],
  ['softmaxlayer',['SoftMaxLayer',['../classInferenceEngine_1_1Builder_1_1SoftMaxLayer.html',1,'InferenceEngine::Builder']]],
  ['spacetodepthlayer',['SpaceToDepthLayer',['../classInferenceEngine_1_1SpaceToDepthLayer.html',1,'InferenceEngine']]],
  ['sparsefillemptyrowslayer',['SparseFillEmptyRowsLayer',['../classInferenceEngine_1_1SparseFillEmptyRowsLayer.html',1,'InferenceEngine']]],
  ['splitlayer',['SplitLayer',['../classInferenceEngine_1_1Builder_1_1SplitLayer.html',1,'InferenceEngine::Builder']]],
  ['splitlayer',['SplitLayer',['../classInferenceEngine_1_1SplitLayer.html',1,'InferenceEngine']]],
  ['stridedslicelayer',['StridedSliceLayer',['../classInferenceEngine_1_1StridedSliceLayer.html',1,'InferenceEngine']]]
];
