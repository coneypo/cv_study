var searchData=
[
  ['operator_3d_3d',['operator==',['../classInferenceEngine_1_1LockedMemory.html#a47c9b5b692667c3b93161f59b9d5911d',1,'InferenceEngine::LockedMemory::operator==()'],['../classInferenceEngine_1_1LockedMemory_3_01void_01_4.html#a3c8afcd4ca4215e4e5b038010120e262',1,'InferenceEngine::LockedMemory&lt; void &gt;::operator==()'],['../classInferenceEngine_1_1LockedMemory_3_01const_01T_01_4.html#a19730b12d1e5b613a150dd3cba798754',1,'InferenceEngine::LockedMemory&lt; const T &gt;::operator==()']]]
];
