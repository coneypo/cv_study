var searchData=
[
  ['multi_2dchannel_20face_20detection_20c_2b_2b_20demo',['Multi-Channel Face Detection C++ Demo',['../_demos_multichannel_demo_fd_README.html',1,'']]],
  ['multi_2dchannel_20human_20pose_20estimation_20c_2b_2b_20demo',['Multi-Channel Human Pose Estimation C++ Demo',['../_demos_multichannel_demo_hpe_README.html',1,'']]],
  ['multi_2dchannel_20c_2b_2b_20demos',['Multi-Channel C++ Demos',['../_demos_multichannel_demo_README.html',1,'']]],
  ['multi_20camera_20multi_20person_20python_2a_20demo',['Multi Camera Multi Person Python* Demo',['../_demos_python_demos_multi_camera_multi_person_tracking_README.html',1,'']]],
  ['migration_20from_20inference_20engine_20plugin_20api_20to_20core_20api',['Migration from Inference Engine Plugin API to Core API',['../_docs_IE_DG_Migration_CoreAPI.html',1,'']]],
  ['multi_2ddevice_20plugin',['Multi-Device Plugin',['../_docs_IE_DG_supported_plugins_MULTI.html',1,'']]],
  ['myriad_20plugin',['MYRIAD Plugin',['../_docs_IE_DG_supported_plugins_MYRIAD.html',1,'']]],
  ['model_20optimizer_20developer_20guide',['Model Optimizer Developer Guide',['../_docs_MO_DG_Deep_Learning_Model_Optimizer_DevGuide.html',1,'']]],
  ['model_20optimization_20techniques',['Model Optimization Techniques',['../_docs_MO_DG_prepare_model_Model_Optimization_Techniques.html',1,'']]],
  ['model_20optimizer_20frequently_20asked_20questions',['Model Optimizer Frequently Asked Questions',['../_docs_MO_DG_prepare_model_Model_Optimizer_FAQ.html',1,'']]],
  ['measure_20accuracy',['Measure Accuracy',['../_docs_Workbench_DG_Measure_Accuracy.html',1,'']]],
  ['model_20name_3a_20action_2drecognition_2d0001_2ddecoder',['Model name: action-recognition-0001-decoder',['../_models_intel_action_recognition_0001_decoder_description_action_recognition_0001_decoder.html',1,'']]],
  ['model_20name_3a_20action_2drecognition_2d0001_2dencoder',['Model name: action-recognition-0001-encoder',['../_models_intel_action_recognition_0001_encoder_description_action_recognition_0001_encoder.html',1,'']]],
  ['model_20name_3a_20driver_2daction_2drecognition_2dadas_2d0002_2ddecoder',['Model name: driver-action-recognition-adas-0002-decoder',['../_models_intel_driver_action_recognition_adas_0002_decoder_description_driver_action_recognition_adas_0002_decoder.html',1,'']]],
  ['model_20name_3a_20driver_2daction_2drecognition_2dadas_2d0002_2dencoder',['Model name: driver-action-recognition-adas-0002-encoder',['../_models_intel_driver_action_recognition_adas_0002_encoder_description_driver_action_recognition_adas_0002_encoder.html',1,'']]],
  ['mobilenetv2_2dint8_2dsparse_2dv1_2dtf_2d0001',['mobilenetv2-int8-sparse-v1-tf-0001',['../_models_intel_mobilenetv2_int8_sparse_v1_tf_0001_description_mobilenetv2_int8_sparse_v1_tf_0001.html',1,'']]],
  ['mobilenetv2_2dint8_2dsparse_2dv2_2dtf_2d0001',['mobilenetv2-int8-sparse-v2-tf-0001',['../_models_intel_mobilenetv2_int8_sparse_v2_tf_0001_description_mobilenetv2_int8_sparse_v2_tf_0001.html',1,'']]],
  ['mobilenetv2_2dint8_2dtf_2d0001',['mobilenetv2-int8-tf-0001',['../_models_intel_mobilenetv2_int8_tf_0001_description_mobilenetv2_int8_tf_0001.html',1,'']]],
  ['metrics',['Metrics',['../_tools_accuracy_checker_accuracy_checker_metrics_README.html',1,'']]],
  ['model_20downloader_20and_20other_20automation_20tools',['Model Downloader and other automation tools',['../_tools_downloader_README.html',1,'']]]
];
