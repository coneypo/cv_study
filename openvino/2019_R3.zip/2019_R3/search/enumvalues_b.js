var searchData=
[
  ['u16',['U16',['../classInferenceEngine_1_1Precision.html#ade75bd7073b4aa966c0dda4025bcd0f5af08511de719988ce14d1467d837392fb',1,'InferenceEngine::Precision']]],
  ['u8',['U8',['../classInferenceEngine_1_1Precision.html#ade75bd7073b4aa966c0dda4025bcd0f5a046eaf31a4345f526ed54271c9fcd39c',1,'InferenceEngine::Precision']]],
  ['unspecified',['UNSPECIFIED',['../classInferenceEngine_1_1Precision.html#ade75bd7073b4aa966c0dda4025bcd0f5ae27ff65d395667d17067e83d932a2045',1,'InferenceEngine::Precision']]]
];
