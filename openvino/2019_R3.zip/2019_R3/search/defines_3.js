var searchData=
[
  ['gna_5fconfig_5fkey',['GNA_CONFIG_KEY',['../gna__config_8hpp.html#a8124b15c4055e25f8c5792f2afe1e822',1,'gna_config.hpp']]],
  ['gna_5fconfig_5fvalue',['GNA_CONFIG_VALUE',['../gna__config_8hpp.html#a208a60b02fdd02d379486a1625bf5ebc',1,'gna_config.hpp']]]
];
