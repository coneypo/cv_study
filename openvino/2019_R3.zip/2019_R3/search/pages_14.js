var searchData=
[
  ['vpu_20plugins',['VPU Plugins',['../_docs_IE_DG_supported_plugins_VPU.html',1,'']]],
  ['view_20inference_20results',['View Inference Results',['../_docs_Workbench_DG_View_Inference_Results.html',1,'']]],
  ['visualize_20model',['Visualize Model',['../_docs_Workbench_DG_Visualize_Model.html',1,'']]],
  ['vehicle_2dattributes_2drecognition_2dbarrier_2d0039',['vehicle-attributes-recognition-barrier-0039',['../_models_intel_vehicle_attributes_recognition_barrier_0039_description_vehicle_attributes_recognition_barrier_0039.html',1,'']]],
  ['vehicle_2ddetection_2dadas_2d0002',['vehicle-detection-adas-0002',['../_models_intel_vehicle_detection_adas_0002_description_vehicle_detection_adas_0002.html',1,'']]],
  ['vehicle_2ddetection_2dadas_2dbinary_2d0001',['vehicle-detection-adas-binary-0001',['../_models_intel_vehicle_detection_adas_binary_0001_description_vehicle_detection_adas_binary_0001.html',1,'']]],
  ['vehicle_2dlicense_2dplate_2ddetection_2dbarrier_2d0106',['vehicle-license-plate-detection-barrier-0106',['../_models_intel_vehicle_license_plate_detection_barrier_0106_description_vehicle_license_plate_detection_barrier_0106.html',1,'']]]
];
