var searchData=
[
  ['layer_5ftype',['layer_type',['../structInferenceEngine_1_1InferenceEngineProfileInfo.html#a5ad060fc227cdf5cf64970c156485c9d',1,'InferenceEngine::InferenceEngineProfileInfo']]],
  ['layout',['layout',['../classInferenceEngine_1_1Data.html#aea3b125b5618450e64fa509caa90a08d',1,'InferenceEngine::Data']]],
  ['levels',['levels',['../classInferenceEngine_1_1QuantizeLayer.html#a123e69401b350fc3627f80c2c3f1524a',1,'InferenceEngine::QuantizeLayer']]]
];
