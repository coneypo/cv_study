var searchData=
[
  ['winograd_20algorithmic_20tuning',['Winograd Algorithmic Tuning',['../_docs_Workbench_DG_Winograd_Algorithmic_Tuning.html',1,'']]],
  ['work_20with_20models_20and_20sample_20datasets',['Work with Models and Sample Datasets',['../_docs_Workbench_DG_Work_with_Models_and_Sample_Datasets.html',1,'']]]
];
