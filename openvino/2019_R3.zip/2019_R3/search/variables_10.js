var searchData=
[
  ['rc',['rc',['../structInferenceEngine_1_1QueryNetworkResult.html#a4cc512d1eb0806ecf1d0b79c7f6283e2',1,'InferenceEngine::QueryNetworkResult']]],
  ['reader',['reader',['../classInferenceEngine_1_1CNNNetwork.html#a60426a7f84cc3e57868f59e601427deb',1,'InferenceEngine::CNNNetwork']]],
  ['realtime_5fusec',['realTime_uSec',['../structInferenceEngine_1_1InferenceEngineProfileInfo.html#a38ebc89f685e65ffe28a9542b465eb82',1,'InferenceEngine::InferenceEngineProfileInfo']]],
  ['resp',['resp',['../structInferenceEngine_1_1QueryNetworkResult.html#a61620288e17695f9c5a6761fde1c828e',1,'InferenceEngine::QueryNetworkResult']]],
  ['return_5fcounts',['return_counts',['../classInferenceEngine_1_1UniqueLayer.html#ad4c10aa98936397b348604840bb1d43c',1,'InferenceEngine::UniqueLayer']]],
  ['return_5finverse',['return_inverse',['../classInferenceEngine_1_1UniqueLayer.html#a3e5453de78bd5f9e2bf9a003cb6d11cf',1,'InferenceEngine::UniqueLayer']]]
];
