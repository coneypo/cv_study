var searchData=
[
  ['hasstoragetype',['hasStorageType',['../classInferenceEngine_1_1Precision.html#a1f91074f540e6d21da96408988401e44',1,'InferenceEngine::Precision']]]
];
