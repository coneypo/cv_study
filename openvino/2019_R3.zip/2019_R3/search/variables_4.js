var searchData=
[
  ['depth',['depth',['../classInferenceEngine_1_1OneHotLayer.html#a3350862a93d030b9478c02f6935998d3',1,'InferenceEngine::OneHotLayer']]],
  ['desc',['desc',['../structInferenceEngine_1_1DataConfig.html#af43e585030006f91039e0144292b575f',1,'InferenceEngine::DataConfig']]],
  ['description',['description',['../structInferenceEngine_1_1Version.html#acce46690f8fdd1b8ecf29c6915f8528b',1,'InferenceEngine::Version']]],
  ['device',['device',['../structInferenceEngine_1_1FindPluginRequest.html#a6d2d3dcaf06eafbf2c97c0d242671c3d',1,'InferenceEngine::FindPluginRequest']]],
  ['dim',['dim',['../classInferenceEngine_1_1CropLayer.html#a5f26605812e05c1d16beaaefd69dc24f',1,'InferenceEngine::CropLayer']]],
  ['dims',['dims',['../classInferenceEngine_1_1Data.html#a22beb6fec19c44d4747759dbb886e507',1,'InferenceEngine::Data']]],
  ['direction',['direction',['../classInferenceEngine_1_1RNNSequenceLayer.html#a067f2270b7cb85fe96b62ce33bcb1887',1,'InferenceEngine::RNNSequenceLayer']]],
  ['dynbatchsupport',['dynBatchSupport',['../structInferenceEngine_1_1LayerConfig.html#a31bd118feaf9c53b2532899c64fe44b5',1,'InferenceEngine::LayerConfig']]]
];
