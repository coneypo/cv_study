var searchData=
[
  ['low_2dprecision_208_2dbit_20integer_20inference',['Low-Precision 8-bit Integer Inference',['../_docs_IE_DG_Int8Inference.html',1,'']]],
  ['legal_20information',['Legal Information',['../_docs_IE_DG_Legal_Information.html',1,'']]],
  ['legacy_20mode_20for_20caffe_2a_20custom_20layers',['Legacy Mode for Caffe* Custom Layers',['../_docs_MO_DG_prepare_model_customize_model_optimizer_Legacy_Mode_for_Caffe_Custom_Layers.html',1,'']]],
  ['landmarks_2dregression_2dretail_2d0009',['landmarks-regression-retail-0009',['../_models_intel_landmarks_regression_retail_0009_description_landmarks_regression_retail_0009.html',1,'']]],
  ['license_2dplate_2drecognition_2dbarrier_2d0001',['license-plate-recognition-barrier-0001',['../_models_intel_license_plate_recognition_barrier_0001_description_license_plate_recognition_barrier_0001.html',1,'']]]
];
