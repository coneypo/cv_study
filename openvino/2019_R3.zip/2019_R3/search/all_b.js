var searchData=
[
  ['known_20issues_20and_20limitations',['Known Issues and Limitations',['../_docs_IE_DG_Known_Issues_Limitations.html',1,'']]],
  ['known_20issues_20and_20limitations_20in_20the_20model_20optimizer',['Known Issues and Limitations in the Model Optimizer',['../_docs_MO_DG_Known_Issues_Limitations.html',1,'']]],
  ['keep_5fdims',['keep_dims',['../classInferenceEngine_1_1ReduceLayer.html#a4356fb560801742165da60a356451de1',1,'InferenceEngine::ReduceLayer']]],
  ['key_5fconfig_5ffile',['KEY_CONFIG_FILE',['../namespaceInferenceEngine_1_1PluginConfigParams.html#a8b8c53f571862c6c394c67f3a66e7db2',1,'InferenceEngine::PluginConfigParams']]],
  ['key_5fcpu_5fbind_5fthread',['KEY_CPU_BIND_THREAD',['../namespaceInferenceEngine_1_1PluginConfigParams.html#a1264fc1aa7f58c908e884eb8fbaff8b2',1,'InferenceEngine::PluginConfigParams']]],
  ['key_5fcpu_5fthreads_5fnum',['KEY_CPU_THREADS_NUM',['../namespaceInferenceEngine_1_1PluginConfigParams.html#afd027d0800ad52c8658bb0098848d5ad',1,'InferenceEngine::PluginConfigParams']]],
  ['key_5fdevice_5fid',['KEY_DEVICE_ID',['../namespaceInferenceEngine_1_1PluginConfigParams.html#a5f4163dbc2c805b6adcadb4b90033d0b',1,'InferenceEngine::PluginConfigParams']]],
  ['key_5fdump_5fexec_5fgraph_5fas_5fdot',['KEY_DUMP_EXEC_GRAPH_AS_DOT',['../namespaceInferenceEngine_1_1PluginConfigParams.html#a02ac10820f3dc0b48358a343d54f3a52',1,'InferenceEngine::PluginConfigParams']]],
  ['key_5fdump_5fkernels',['KEY_DUMP_KERNELS',['../namespaceInferenceEngine_1_1PluginConfigParams.html#a492dd572580d2a31c98180403f39befb',1,'InferenceEngine::PluginConfigParams']]],
  ['key_5fdyn_5fbatch_5flimit',['KEY_DYN_BATCH_LIMIT',['../namespaceInferenceEngine_1_1PluginConfigParams.html#a66d52f19002274e481440b0c3a2d12e3',1,'InferenceEngine::PluginConfigParams']]],
  ['key_5fexclusive_5fasync_5frequests',['KEY_EXCLUSIVE_ASYNC_REQUESTS',['../namespaceInferenceEngine_1_1PluginConfigParams.html#a411b655991a73fdf759a52a8a8da80d7',1,'InferenceEngine::PluginConfigParams']]],
  ['key_5flog_5flevel',['KEY_LOG_LEVEL',['../namespaceInferenceEngine_1_1PluginConfigParams.html#a0ad8e81ea6681cb216494f308f353a1b',1,'InferenceEngine::PluginConfigParams']]],
  ['key_5fperf_5fcount',['KEY_PERF_COUNT',['../namespaceInferenceEngine_1_1PluginConfigParams.html#a06e7d1c7f8905f0915d73eba49fa1bed',1,'InferenceEngine::PluginConfigParams']]],
  ['key_5fsingle_5fthread',['KEY_SINGLE_THREAD',['../namespaceInferenceEngine_1_1PluginConfigParams.html#a70e7ec5da93eb586ed90c9313c934cdf',1,'InferenceEngine::PluginConfigParams']]],
  ['key_5ftuning_5ffile',['KEY_TUNING_FILE',['../namespaceInferenceEngine_1_1PluginConfigParams.html#af65c57faa410f2dd1c56b311092c5ba4',1,'InferenceEngine::PluginConfigParams']]],
  ['key_5ftuning_5fmode',['KEY_TUNING_MODE',['../namespaceInferenceEngine_1_1PluginConfigParams.html#a89f158fb06300ab3b4a64d27f6140587',1,'InferenceEngine::PluginConfigParams']]]
];
