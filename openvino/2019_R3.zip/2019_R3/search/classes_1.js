var searchData=
[
  ['batchnormalizationlayer',['BatchNormalizationLayer',['../classInferenceEngine_1_1Builder_1_1BatchNormalizationLayer.html',1,'InferenceEngine::Builder']]],
  ['batchnormalizationlayer',['BatchNormalizationLayer',['../classInferenceEngine_1_1BatchNormalizationLayer.html',1,'InferenceEngine']]],
  ['binaryconvolutionlayer',['BinaryConvolutionLayer',['../classInferenceEngine_1_1BinaryConvolutionLayer.html',1,'InferenceEngine']]],
  ['blob',['Blob',['../classInferenceEngine_1_1Blob.html',1,'InferenceEngine']]],
  ['blockingdesc',['BlockingDesc',['../classInferenceEngine_1_1BlockingDesc.html',1,'InferenceEngine']]],
  ['body',['Body',['../structInferenceEngine_1_1TensorIterator_1_1Body.html',1,'InferenceEngine::TensorIterator']]],
  ['broadcastlayer',['BroadcastLayer',['../classInferenceEngine_1_1BroadcastLayer.html',1,'InferenceEngine']]]
];
