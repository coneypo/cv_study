var searchData=
[
  ['fp16',['FP16',['../classInferenceEngine_1_1Precision.html#ade75bd7073b4aa966c0dda4025bcd0f5a084e737560206865337ee681e1ab3f5a',1,'InferenceEngine::Precision']]],
  ['fp32',['FP32',['../classInferenceEngine_1_1Precision.html#ade75bd7073b4aa966c0dda4025bcd0f5a6b062312b968a46ae0baf14cc3665e1e',1,'InferenceEngine::Precision']]],
  ['fwd',['FWD',['../classInferenceEngine_1_1RNNSequenceLayer.html#a6e831e42636d72cb8b8d1c03dfae12abac742554fe3954954cb7900cdce2b0f76',1,'InferenceEngine::RNNSequenceLayer']]]
];
