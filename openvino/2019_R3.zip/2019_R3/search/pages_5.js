var searchData=
[
  ['extending_20the_20model_20optimizer_20with_20new_20primitives',['Extending the Model Optimizer with New Primitives',['../_docs_MO_DG_prepare_model_customize_model_optimizer_Extending_Model_Optimizer_with_New_Primitives.html',1,'']]],
  ['extending_20the_20mxnet_20model_20optimizer_20with_20new_20primitives',['Extending the MXNet Model Optimizer with New Primitives',['../_docs_MO_DG_prepare_model_customize_model_optimizer_Extending_MXNet_Model_Optimizer_with_New_Primitives.html',1,'']]],
  ['enter_20docker_2a_20container_20with_20dl_20workbench',['Enter Docker* Container with DL Workbench',['../_docs_Workbench_DG_Enter_Docker_Container.html',1,'']]],
  ['emotion_2drecognition_2dretail_2d0003',['emotion-recognition-retail-0003',['../_models_intel_emotions_recognition_retail_0003_description_emotions_recognition_retail_0003.html',1,'']]]
];
