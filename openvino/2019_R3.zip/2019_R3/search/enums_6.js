var searchData=
[
  ['poolingtype',['PoolingType',['../classInferenceEngine_1_1Builder_1_1PoolingLayer.html#a1099461dbbb5bfead241e1966dc85c77',1,'InferenceEngine::Builder::PoolingLayer']]],
  ['pooltype',['PoolType',['../classInferenceEngine_1_1PoolingLayer.html#ab43fd40baddc9e43ec9772f2ea20b07d',1,'InferenceEngine::PoolingLayer']]]
];
