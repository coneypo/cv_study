var searchData=
[
  ['gaze_20estimation_20demo',['Gaze Estimation Demo',['../_demos_gaze_estimation_demo_README.html',1,'']]],
  ['glossary',['Glossary',['../_docs_IE_DG_Glossary.html',1,'']]],
  ['gpu_20plugin',['GPU Plugin',['../_docs_IE_DG_supported_plugins_CL_DNN.html',1,'']]],
  ['gna_20plugin',['GNA Plugin',['../_docs_IE_DG_supported_plugins_GNA.html',1,'']]],
  ['get_20a_20deep_20learning_20model_20performance_20boost_20with_20intel®_20platforms',['Get a Deep Learning Model Performance Boost with Intel® Platforms',['../_docs_performance_benchmarks.html',1,'']]],
  ['generate_20datasets',['Generate Datasets',['../_docs_Workbench_DG_Generate_Datasets.html',1,'']]],
  ['gaze_2destimation_2dadas_2d0002',['gaze-estimation-adas-0002',['../_models_intel_gaze_estimation_adas_0002_description_gaze_estimation_adas_0002.html',1,'']]]
];
